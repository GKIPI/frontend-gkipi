export default function Home() {
  return (
    <div className="flex flex-row justify-center h-96">
      <div className="w-3/4 flex items-center">
        <h1 className="font-montserrat text-4xl font-semibold text-center">
          Welcome to Admin Dashboard GKI Pondok Indah
        </h1>
      </div>
    </div>
  );
}
