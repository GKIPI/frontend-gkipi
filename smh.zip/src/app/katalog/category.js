const category = [
  {
    title: "Beauty & Health",
    link: "beauty-and-health",
  },
  {
    title: "Sport",
    link: "sport",
  },
  {
    title: "Property",
    link: "property",
  },
  {
    title: "Fashion & Accessories",
    link: "fashion-and-accessories",
  },
  {
    title: "Food & Beverage",
    link: "food-and-beverage",
  },
  {
    title: "Electronics",
    link: "electronics",
  },
  {
    title: "Book & Stationary",
    link: "book-and-stationary",
  },
  {
    title: "Other",
    link: "other",
  },
  {
    title: "All",
    link: "",
  },
]

module.exports = category;