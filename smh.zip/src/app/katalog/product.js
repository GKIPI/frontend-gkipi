const products = [
  {
    img: '/dummy/gkpi1.jpeg',
    title: 'Bacang Ketan',
    price: 'Rp25.000',
    src: 'https://www.instagram.com/komunitas_profesi/'
  },
  {
    img: '/dummy/gkpi1.jpeg',
    title: 'Bacang Nasi',
    price: 'Rp22.500',
    src: 'https://www.instagram.com/komunitas_profesi/'
  },
  {
    img: '/dummy/gkpi2.jpeg',
    title: 'Lele Bumbu Parakan Salak',
    price: 'Rp40.000',
    src: 'https://www.instagram.com/komunitas_profesi/'
  },
  {
    img: '/dummy/gkpi3.jpeg',
    title: 'Launchbox Bag',
    price: 'Rp99.800',
    src: 'https://www.instagram.com/komunitas_profesi/'
  },
  {
    img: '/dummy/gkpi4.jpeg',
    title: 'Tas Belanja',
    price: 'Rp148.000',
    src: 'https://www.instagram.com/komunitas_profesi/'
  },
  {
    img: '/dummy/gkpi6.jpeg',
    title: 'Sling Bag',
    price: 'Rp174.700',
    src: 'https://www.instagram.com/komunitas_profesi/'
  },
  {
    img: '/dummy/gkpi7.jpeg',
    title: 'Macrame Clutchbag',
    price: 'Rp115.800',
    src: 'https://www.instagram.com/komunitas_profesi/'
  },
]

module.exports = products