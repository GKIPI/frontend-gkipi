(() => {
var exports = {};
exports.id = 427;
exports.ids = [427];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 6500:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'admin',
        {
        children: [
        'dashboard',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3749)), "/home/petrusariaa/GitHub/GKIPI-project/frontend-gkipi/src/app/admin/dashboard/page.jsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1981)), "/home/petrusariaa/GitHub/GKIPI-project/frontend-gkipi/src/app/layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/home/petrusariaa/GitHub/GKIPI-project/frontend-gkipi/src/app/admin/dashboard/page.jsx"];

    

    const originalPathname = "/admin/dashboard/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/admin/dashboard/page","pathname":"/admin/dashboard","bundlePath":"app/admin/dashboard/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 3173:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7952))

/***/ }),

/***/ 7952:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Dasboard)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./public/Logo.png
var Logo = __webpack_require__(1930);
// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var index_esm = __webpack_require__(5816);
;// CONCATENATED MODULE: ./src/app/admin/dashboard/JobSeeker.jsx


function JobSeeker() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "space-y-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "font-montserrat text-2xl md:text-4xl font-bold pt-16",
                children: "Job Seeker"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "font-montserrat bg-zinc-800 text-slate-200 px-4 py-2 hover:bg-transparent hover:text-zinc-800 hover:outline hover:outline-2 hover:outline-zinc-800 transi duration-200",
                            children: "Review (5)"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                            className: "w-full border-collapse border border-zinc-800 text-left table-fixed",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                    className: "font-montserrat text-xs md:text-sm",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border border-b border-zinc-800 bg-zinc-200",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2 pl-4",
                                                children: "Name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2 line-clamp-1",
                                                children: "Education"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2",
                                                children: "Skills"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2",
                                                children: "CV"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                    className: "text-sm font-montserrat text-zinc-600",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "py-4 pl-4 border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "Joanna Anderson"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "IT Undergraduate"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "Adobe Illustrator, Adobe Photosop"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-row items-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineFileAdd */.O1u, {
                                                                title: "add/update",
                                                                size: 25,
                                                                className: "hover:text-amber-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineFileSearch */.Ehc, {
                                                                title: "view PDF",
                                                                size: 25,
                                                                className: "hover:text-blue-400"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-row items-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineEye */.Zju, {
                                                                size: 25,
                                                                title: "view",
                                                                className: "hover:text-blue-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineForm */.lFz, {
                                                                size: 25,
                                                                title: "edit",
                                                                className: "hover:text-amber-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineDelete */.VPh, {
                                                                size: 25,
                                                                title: "delete",
                                                                className: "hover:text-red-400"
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/admin/dashboard/JobVacancies.jsx


function JobVacancies() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "space-y-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "font-montserrat text-2xl md:text-4xl font-bold pt-16",
                children: "Job Vacancies"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "font-montserrat bg-zinc-800 text-slate-200 px-4 py-2 hover:bg-transparent hover:text-zinc-800 hover:outline hover:outline-2 hover:outline-zinc-800 transi duration-200",
                            children: "Review (5)"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                            className: "w-full border-collapse border border-zinc-800 text-left table-fixed",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                    className: "font-montserrat text-xs md:text-sm",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border border-b border-zinc-800 bg-zinc-200",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2 pl-4",
                                                children: "Job"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2 line-clamp-1",
                                                children: "Company"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2",
                                                children: "Location"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2",
                                                children: "Notes"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2",
                                                children: "Poster"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                    className: "text-sm font-montserrat text-zinc-600",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "py-4 pl-4 border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "Creative Content Writer"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "Digiexpo Indonesia"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "Jakarta Barat"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-2",
                                                    children: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magnam excepturi quaerat nemo, ducimus iure hic dolore fuga nesciunt sed laudantium!"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-row items-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineFileAdd */.O1u, {
                                                                title: "add/update",
                                                                size: 25,
                                                                className: "hover:text-amber-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineFileSearch */.Ehc, {
                                                                title: "view PDF",
                                                                size: 25,
                                                                className: "hover:text-blue-400"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-row items-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineEye */.Zju, {
                                                                size: 25,
                                                                title: "view",
                                                                className: "hover:text-blue-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineForm */.lFz, {
                                                                size: 25,
                                                                title: "edit",
                                                                className: "hover:text-amber-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineDelete */.VPh, {
                                                                size: 25,
                                                                title: "delete",
                                                                className: "hover:text-red-400"
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/admin/dashboard/Catalog.jsx


function Catalog() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "space-y-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "font-montserrat text-2xl md:text-4xl font-bold pt-16",
                children: "My Catalog"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "font-montserrat bg-zinc-800 text-slate-200 px-4 py-2 hover:bg-transparent hover:text-zinc-800 hover:outline hover:outline-2 hover:outline-zinc-800 transi duration-200",
                            children: "Review (5)"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                            className: "w-full border-collapse border border-zinc-800 text-left table-fixed",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                    className: "font-montserrat text-xs md:text-sm",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border border-b border-zinc-800 bg-zinc-200",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2 pl-4",
                                                children: "Name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2 line-clamp-1",
                                                children: "Category"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2",
                                                children: "Price"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2",
                                                children: "Contact"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2",
                                                children: "Picture"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "py-2"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                    className: "text-sm font-montserrat text-zinc-600",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "py-4 pl-4 border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "Bible Case"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "Stationary"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-1",
                                                    children: "Rp50.000,-"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "line-clamp-2",
                                                    children: "08951234567"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-row items-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineFileAdd */.O1u, {
                                                                title: "add/update",
                                                                size: 25,
                                                                className: "hover:text-amber-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineFileSearch */.Ehc, {
                                                                title: "view PDF",
                                                                size: 25,
                                                                className: "hover:text-blue-400"
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "border-b border-zinc-800",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-row items-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineEye */.Zju, {
                                                                size: 25,
                                                                title: "view",
                                                                className: "hover:text-blue-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineForm */.lFz, {
                                                                size: 25,
                                                                title: "edit",
                                                                className: "hover:text-amber-400"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* AiOutlineDelete */.VPh, {
                                                                size: 25,
                                                                title: "delete",
                                                                className: "hover:text-red-400"
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var bs_index_esm = __webpack_require__(930);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./src/app/admin/dashboard/Home.jsx

function Home() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex flex-row justify-center h-96",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-3/4 flex items-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "font-montserrat text-4xl font-semibold text-center",
                children: "Welcome to Admin Dashboard GKI Pondok Indah"
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/app/admin/dashboard/page.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









const DASHBOARD_NAVIGATION = [
    {
        title: "Home",
        page: /*#__PURE__*/ jsx_runtime_.jsx(Home, {})
    },
    {
        title: "Job Seeker",
        page: /*#__PURE__*/ jsx_runtime_.jsx(JobSeeker, {}),
        reqCount: 2
    },
    {
        title: "Job Vacancies",
        page: /*#__PURE__*/ jsx_runtime_.jsx(JobVacancies, {}),
        reqCount: 1
    },
    {
        title: "My Catalog",
        page: /*#__PURE__*/ jsx_runtime_.jsx(Catalog, {}),
        reqCount: 6
    }
];
function Dasboard() {
    const [activeIndex, setActiveIndex] = (0,react_.useState)(0);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "min-h-screen flex flex-row",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("aside", {
                className: "hidden md:block w-[25%] bg-zinc-200",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-[30%] w-full flex justify-center items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: Logo["default"],
                                className: "w-28 bg-secondary"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col justify-between h-[32rem]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "px-6 font-montserrat text-lg space-y-4",
                                children: [
                                    activeIndex === 0 ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "text-[#B68D40] font-semibold",
                                        children: DASHBOARD_NAVIGATION[0].title
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: {
                                            pathname: "dashboard"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            onClick: ()=>{
                                                setActiveIndex(0);
                                            },
                                            children: DASHBOARD_NAVIGATION[0].title
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "font-bold",
                                                children: "Lowongan Kerja"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col pl-4 items-start",
                                                children: [
                                                    activeIndex === 1 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                        className: "text-[#B68D40] font-semibold",
                                                        children: [
                                                            DASHBOARD_NAVIGATION[1].title,
                                                            " (",
                                                            DASHBOARD_NAVIGATION[1].reqCount,
                                                            ")"
                                                        ]
                                                    }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: {
                                                            pathname: "dashboard",
                                                            query: {
                                                                page: DASHBOARD_NAVIGATION[1].title
                                                            }
                                                        },
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                            onClick: ()=>{
                                                                setActiveIndex(1);
                                                            },
                                                            children: [
                                                                DASHBOARD_NAVIGATION[1].title,
                                                                " (",
                                                                DASHBOARD_NAVIGATION[1].reqCount,
                                                                ")"
                                                            ]
                                                        })
                                                    }),
                                                    activeIndex === 2 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                        className: "text-[#B68D40] font-semibold",
                                                        children: [
                                                            DASHBOARD_NAVIGATION[2].title,
                                                            " (",
                                                            DASHBOARD_NAVIGATION[2].reqCount,
                                                            ")"
                                                        ]
                                                    }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: {
                                                            pathname: "dashboard",
                                                            query: {
                                                                page: DASHBOARD_NAVIGATION[2].title
                                                            }
                                                        },
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                            onClick: ()=>{
                                                                setActiveIndex(2);
                                                            },
                                                            children: [
                                                                DASHBOARD_NAVIGATION[2].title,
                                                                " (",
                                                                DASHBOARD_NAVIGATION[2].reqCount,
                                                                ")"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "font-bold",
                                                children: "Katalog Online"
                                            }),
                                            activeIndex === 3 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                className: "pl-4 text-[#B68D40] font-semibold",
                                                children: [
                                                    DASHBOARD_NAVIGATION[3].title,
                                                    " (",
                                                    DASHBOARD_NAVIGATION[3].reqCount,
                                                    ")"
                                                ]
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                className: "pl-4",
                                                onClick: ()=>{
                                                    setActiveIndex(3);
                                                },
                                                children: [
                                                    DASHBOARD_NAVIGATION[3].title,
                                                    " (",
                                                    DASHBOARD_NAVIGATION[3].reqCount,
                                                    ")"
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "px-6 space-y-8",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/admin",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "font-montserrat text-2xl px-5 py-2.5 hover:bg-zinc-800 transition-colors duration-200 hover:text-slate-200 rounded-md",
                                            children: "Sign Out"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "border-b border-zinc-400"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "font-montserrat text-sm text-zinc-400",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Telp : (021) 7503247"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "e-Mail : emailGKIPI@gmail.com"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "w-full md:w-[75%] py-4 px-2 md:px-8 flex flex-col",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "flex gap-2 items-center font-montserrat italic text-zinc-800",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(bs_index_esm/* BsPersonCircle */._Tb, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "GKI Pondok Indah (Admin)"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: DASHBOARD_NAVIGATION[activeIndex].page
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 3749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/petrusariaa/GitHub/GKIPI-project/frontend-gkipi/src/app/admin/dashboard/page.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [697,776,775,407,930,816,575], () => (__webpack_exec__(6500)));
module.exports = __webpack_exports__;

})();