(() => {
var exports = {};
exports.id = 262;
exports.ids = [262];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 4705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'lowongan',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6254)), "/home/petrusariaa/GitHub/GKIPI-project/frontend-gkipi/src/app/lowongan/page.js"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1981)), "/home/petrusariaa/GitHub/GKIPI-project/frontend-gkipi/src/app/layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/home/petrusariaa/GitHub/GKIPI-project/frontend-gkipi/src/app/lowongan/page.js"];

    

    const originalPathname = "/lowongan/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/lowongan/page","pathname":"/lowongan","bundlePath":"app/lowongan/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 9136:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8830))

/***/ }),

/***/ 8830:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Lowongan)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./src/app/components/navbar.js
var navbar = __webpack_require__(1832);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./src/app/components/sidebar.js
/* __next_internal_client_entry_do_not_use__ default auto */ 

function Sidebar() {
    const [isLogin, setIsLogin] = (0,react_.useState)(false);
    const [selectedIndustries, setSelectedIndustries] = (0,react_.useState)([]);
    const [selectedTitles, setSelectedTitles] = (0,react_.useState)([]);
    const handleSearch = ()=>{
        console.log("Selected Industries:", selectedIndustries);
        console.log("Selected Titles:", selectedTitles);
    };
    const handleIndustryChange = (event)=>{
        const industry = event.target.value;
        const isChecked = event.target.checked;
        const isIndustrySelected = selectedIndustries.includes(industry);
        if (isChecked && !isIndustrySelected) {
            setSelectedIndustries([
                ...selectedIndustries,
                industry
            ]);
        } else if (!isChecked && isIndustrySelected) {
            setSelectedIndustries(selectedIndustries.filter((item)=>item !== industry));
        }
        console.log("Selected Industries:", selectedIndustries);
    };
    const handleTitleChange = (event)=>{
        const title = event.target.value;
        const isChecked = event.target.checked;
        const isTitleSelected = selectedTitles.includes(title);
        if (isChecked && !isTitleSelected) {
            setSelectedTitles([
                ...selectedTitles,
                title
            ]);
        } else if (!isChecked && isTitleSelected) {
            setSelectedTitles(selectedTitles.filter((item)=>item !== title));
        }
        console.log("Selected Titles:", selectedTitles);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "lg:min-w-[25%] ",
        children: isLogin ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "logined h-full bg-tertiary",
            children: "sidebar not logged in yet"
        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "hidden lg:flex not-logined h-full justify-center items-center",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "border-2 border-primary w-full m-2 p-2 h-min",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-[24px]",
                        children: "Search by:"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-[20px] m-2",
                        children: "Industry"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mx-3",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "industrial",
                                        checked: selectedIndustries.includes("industrial"),
                                        onChange: handleIndustryChange
                                    }),
                                    "Industrial / Manufacturing"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "insurance",
                                        checked: selectedIndustries.includes("insurance"),
                                        onChange: handleIndustryChange
                                    }),
                                    "Insurance"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "fmcg",
                                        checked: selectedIndustries.includes("fmcg"),
                                        onChange: handleIndustryChange
                                    }),
                                    "FMCG"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "media",
                                        checked: selectedIndustries.includes("media"),
                                        onChange: handleIndustryChange
                                    }),
                                    "Media & Agency"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "financial",
                                        checked: selectedIndustries.includes("financial"),
                                        onChange: handleIndustryChange
                                    }),
                                    "Financial Service"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "property",
                                        checked: selectedIndustries.includes("property"),
                                        onChange: handleIndustryChange
                                    }),
                                    "Property"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "retail",
                                        checked: selectedIndustries.includes("retail"),
                                        onChange: handleIndustryChange
                                    }),
                                    "Retail"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-[20px] m-2",
                        children: "Title"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mx-3",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "staff",
                                        checked: selectedTitles.includes("staff"),
                                        onChange: handleTitleChange
                                    }),
                                    "Staff"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "supervisor",
                                        checked: selectedTitles.includes("supervisor"),
                                        onChange: handleTitleChange
                                    }),
                                    "Supervisor"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "manager",
                                        checked: selectedTitles.includes("manager"),
                                        onChange: handleTitleChange
                                    }),
                                    "Manager"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "generalManager",
                                        checked: selectedTitles.includes("generalManager"),
                                        onChange: handleTitleChange
                                    }),
                                    "General Manager"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "w-max",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "checkbox",
                                        value: "dicrector",
                                        checked: selectedTitles.includes("dicrector"),
                                        onChange: handleTitleChange
                                    }),
                                    "Director"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                        ]
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./public/dummy/gkpi1.jpeg
/* harmony default export */ const gkpi1 = ({"src":"/_next/static/media/gkpi1.c761445b.jpeg","height":1024,"width":770,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAYDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAfEAAABQQDAAAAAAAAAAAAAAAAAQIDEgQFERMhIoH/xAAVAQEBAAAAAAAAAAAAAAAAAAAEBv/EABgRAAIDAAAAAAAAAAAAAAAAAAABAgMR/9oADAMBAAIRAxEAPwCDU01nXamik4y5s6m3ha4xwZK95IAADKeFSw//2Q==","blurWidth":6,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/buildings.png
/* harmony default export */ const buildings = ({"src":"/_next/static/media/buildings.897f95a8.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAMFBMVEVMaXEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbsZG/AAAAEHRSTlMAnYOL3tm37wx7WsQXz2lCa9kmBQAAAAlwSFlzAAALEwAACxMBAJqcGAAAADtJREFUeJwdiMcRwDAMw0jJai7x/ttGCT7AAUDOJ9Fkcawvtsqw9p2if0hJnw2oCi1Y4ImwUIev43TyBSipASyaKG96AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/map.png
/* harmony default export */ const map = ({"src":"/_next/static/media/map.8647dd3f.png","height":20,"width":20,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAJFBMVEVMaXEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/eFplAAAAC3RSTlMAtUgCWSLxp27lFhL9RDoAAAAJcEhZcwAACxMAAAsTAQCanBgAAAA0SURBVHicHYoHDgAwCALRDgf//2+phADJAcDNHJKzin8Zu2kawUzGIGlOwSEL596jkvdWPCb0AQs7dnjwAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/swiper/swiper-react.mjs + 3 modules
var swiper_react = __webpack_require__(2797);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.css
var swiper = __webpack_require__(3754);
// EXTERNAL MODULE: ./node_modules/swiper/modules/navigation.css
var navigation = __webpack_require__(2119);
// EXTERNAL MODULE: ./node_modules/swiper/modules/pagination.css
var pagination = __webpack_require__(3141);
// EXTERNAL MODULE: ./node_modules/swiper/modules/index.mjs + 26 modules
var modules = __webpack_require__(1987);
;// CONCATENATED MODULE: ./src/app/lowongan/page.js
/* __next_internal_client_entry_do_not_use__ default auto */ 












function Lowongan() {
    const [activePage, setActivePage] = (0,react_.useState)(true);
    const onSelect = (value)=>{
        setActivePage(!activePage);
    };
    const generateCardData = ()=>{
        const cardData = [];
        for(let i = 1; i <= 24; i++){
            cardData.push({
                title: `Card ${i}`,
                content: `This is the content of Card ${i}.`,
                company: `Company ${i}`,
                location: `Location ${i}`
            });
        }
        return cardData;
    };
    const cards = generateCardData();
    const chunkArray = (arr, size)=>{
        const chunkedArray = [];
        for(let i = 0; i < arr.length; i += size){
            chunkedArray.push(arr.slice(i, i + size));
        }
        return chunkedArray;
    };
    const chunkedCards = chunkArray(cards, 6);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "mim-h-screen w-screen overflow-x-hidden overflow-y-hidden text-[24px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar/* default */.Z, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex justify-center items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: onSelect,
                        className: "font-montserrat font-[900] m-7 cursor-pointer hover:bg-primary hover:text-white p-2 " + (activePage ? "text-black" : "text-black/25"),
                        children: "Job Seeker"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: onSelect,
                        className: "font-montserrat font-[900] m-7 cursor-pointer hover:bg-primary hover:text-white p-2 " + (activePage ? "text-black/25" : "text-black"),
                        children: "Job Vacancies"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "h-full flex",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "container mx-auto px-4 sm:px-8 flex-grow w-[75%]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* Swiper */.tq, {
                                modules: [
                                    modules/* Navigation */.W_,
                                    modules/* Pagination */.tl,
                                    modules/* Scrollbar */.LW,
                                    modules/* A11y */.s5
                                ],
                                slidesPerView: 1,
                                pagination: {
                                    clickable: true
                                },
                                children: chunkedCards.map((card, index)=>/*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Card, {
                                            array: card
                                        })
                                    }, index))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "swiper-pagination"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
const Card = ({ array })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid gap-2 sm:gap-5 grid-cols-2 lg:grid-cols-3 mx-0 p-[5%] xs:p-5 sm:p-8 md:p-12 w-full overflow-x-hidden overflow-y-hidden",
        children: array.map((card, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "max-h-[370px] w-full shadow-md p-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "bg-slate-300 animate-pulse  h-[250px] w-full overflow-y-hidden"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-xl font-bold mb-2",
                        children: card.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row justify-between mx-3",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex items-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: buildings
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm mx-2",
                                        children: card.company
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex items-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: map
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm mx-2",
                                        children: card.location
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }, i))
    });
};


/***/ }),

/***/ 6254:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/home/petrusariaa/GitHub/GKIPI-project/frontend-gkipi/src/app/lowongan/page.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [697,776,775,869,575,832], () => (__webpack_exec__(4705)));
module.exports = __webpack_exports__;

})();